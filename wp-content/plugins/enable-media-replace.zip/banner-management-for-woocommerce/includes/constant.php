<?php

/**
 * define constant variabes
 * define admin side constant
 * @since 1.0.0
 * @author Multidots
 * @param null
 */
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// define constant for plugin slug
define('WOO_BANNER_MANAGEMENT_PLUGIN_SLUG', 'banner-management-for-woocommerce');
define('WOO_BANNER_MANAGEMENT_PLUGIN_NAME', __('Woocommerce Category Banner Management'));
define('WOO_BANNER_MANAGEMENT_TEXT_DOMAIN', 'banner-management-for-woocommerce');
define('WBM_PLUGIN_VERSION', '1.1.1');
define('WBM_PLUGIN_NAME', 'Woocommerce Category Banner Management');

